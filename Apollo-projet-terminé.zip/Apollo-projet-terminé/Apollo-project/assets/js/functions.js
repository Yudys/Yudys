/*R/P2_Vous devez programmer la fonction qui
permettra à ce bloc de devenir un slider** */

const items = document.getElementById('full-slide').querySelectorAll('li');
const itemCount = items.length;
const iconPrev = document.querySelector('.prev');
const iconNext = document.querySelector('.next');
var count = 0;

function showIconNext() {
  items[count].classList.remove('active');

  if (count < itemCount - 1) {
    count++;
  } else {
    count = 0;
  }
  items[count].classList.add('active');
  console.log(count);
}

function showIconPrev() {
  items[count].classList.remove('active');

  if (count > 0) {
    count--;
  } else {
    count = itemCount - 1;
  }
  items[count].classList.add('active');
  console.log(count);

}

function keypress(e) {
  e = e || window.event;
  if (e.keyCode == '37') {
    showIconPrev();
  } else if (e.keyCode == '39') {
    showIconNext();
  }
}

iconNext.addEventListener('click', showIconNext);
iconPrev.addEventListener('click', showIconPrev);
document.addEventListener('keydown', keypress);


console.log(items);
//console.log(itemCount);

$(document).ready(function() {

  function nav() {

    $('.nav-toggle').click(function() {

      $('.nav').toggleClass('open');

    });

  }

  nav();



  /*R/P3_Vous devrez programmer ce formulaire afin qu’il puisse
envoyer les informations par courriel*****************/

  $('#contact-form').submit(function(e) {
    e.preventDefault();
    $('.comments').empty();
    var postdata = $('#contact-form').serialize();

    $.ajax({
      type: 'POST',
      url: 'contact.php',
      data: postdata,
      dataType: 'json',
      success: function(result) {

        if (result.isSuccess) {
          $("#contact-form").append("<p class='merci'> * Votre message a bien été envoyé. Merci de m'avoir contacté </p>");
          $("#contact-form")[0].reset();
        } else {
          $("#courriel + .comments").html(result.courrielError);
          $("#sujet + .comments").html(result.sujetError);
          $("#message + .comments").html(result.messageError);

        }

      }
    });
  });

});

/*R/P1_ Vous
devrez, lorsque l’utilisateur clique sur l’un des liens,
faire en sorte que le défilement de la page soit fluide et
non direct*************************/

const links = document.querySelectorAll("header ul a");

for (const link of links) {
  link.addEventListener("click", clickHandler);
}

function clickHandler(e) {
  e.preventDefault();
  const href = this.getAttribute("href");

  document.querySelector(href).scrollIntoView({
    behavior: "smooth"
  });
}

//console.log(links)
