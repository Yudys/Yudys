<?php

$array = array("courriel" => "", "sujet" => "", "message" => "", "courrielError" => "", "sujetError" => "", "messageError" => "", "isSuccess" => false);

$emailTo = "jnoq03@gmail.com";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $array["courriel"] = verifyInput($_POST["courriel"]);
    $array["sujet"] = verifyInput($_POST["sujet"]);
    $array["message"] = verifyInput($_POST["message"]);
    $array["isSuccess"] = true;
    $emailText = "";

    if (empty($array["courriel"])) {
        $array["courrielError"] = "*Écrivez votre email s'il vous plaît";
        $array["isSuccess"] = false;
    } else {
        $emailText .= "Courriel: {$array["courriel"]}\n";
    }

    if (empty($array["sujet"])) {
        $array["sujetError"] = "*Écrivez votre sujet s'il vous plaît";
        $array["isSuccess"] = false;
    } else {
        $emailText .= "Sujet: {$array["sujet"]}\n";
    }

    if (empty($array["message"])) {
        $array["messageError"] = "*Écrivez votre message s'il vous plaît";
        $array["isSuccess"] = false;
    } else {
        $emailText .= "Message: {$array["message"]}\n";
    }

    if ($array["isSuccess"]) {
        $headers = "From: <{$array["courriel"]}\r\nReply-To: {$array["courriel"]} {$array["sujet"]} {$array["message"]} ";
        mail($emailTo, "Un message de votre site", $emailText, $headers);
    }
    echo json_encode($array);
}

function isCourriel($var)
{
    return filter_var($var, FILTER_VALIDATE_EMAIL);
}
function verifyInput($var)
{
    $var = trim($var);
    $var = stripcslashes($var);
    $var = htmlspecialchars($var);
    return $var;
}
